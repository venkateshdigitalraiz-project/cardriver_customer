import 'package:flutter/material.dart';

/// Centralized color palette tailored for a high-end Car Driver application.
class AppColors {
  AppColors._();

  // Primary brand colors (Warm Luxury Amber / Electric Gold for Drivers)
  static const Color primary = Color(0xFFFFB300);
  static const Color primaryDark = Color(0xFFFF8F00);
  static const Color primaryLight = Color(0xFFFFD54F);
  static const Color primaryAccent = Color(0xFFFFC107);

  // Secondary & Accent colors (Modern High-tech Cyan / Teal)
  static const Color secondary = Color(0xFF00E5FF);
  static const Color secondaryDark = Color(0xFF00B0FF);
  static const Color accent = Color(0xFFFF6D00);

  // Dark Theme Neutral Colors (Obsidian / Carbon / Dark Slate)
  static const Color backgroundDark = Color(0xFF0F1216);
  static const Color surfaceDark = Color(0xFF191E24);
  static const Color cardDark = Color(0xFF222831);
  static const Color cardBorderDark = Color(0xFF2E3842);
  static const Color inputFillDark = Color(0xFF151A21);
  static const Color inputBorderDark = Color(0xFF2A3441);
  static const Color dividerDark = Color(0xFF252D37);

  // Light Theme Neutral Colors
  static const Color backgroundLight = Color(0xFFF7F9FC);
  static const Color surfaceLight = Color(0xFFFFFFFF);
  static const Color cardLight = Color(0xFFFFFFFF);
  static const Color cardBorderLight = Color(0xFFE4E9F2);
  static const Color inputFillLight = Color(0xFFF1F4F9);
  static const Color inputBorderLight = Color(0xFFD6DFEB);
  static const Color dividerLight = Color(0xFFE2E8F0);

  // Typography Colors (Dark Theme)
  static const Color textPrimaryDark = Color(0xFFF8FAFC);
  static const Color textSecondaryDark = Color(0xFF94A3B8);
  static const Color textTertiaryDark = Color(0xFF64748B);
  static const Color textDisabledDark = Color(0xFF475569);

  // Typography Colors (Light Theme)
  static const Color textPrimaryLight = Color(0xFF0F172A);
  static const Color textSecondaryLight = Color(0xFF475569);
  static const Color textTertiaryLight = Color(0xFF94A3B8);
  static const Color textDisabledLight = Color(0xFFCBD5E1);

  // Status & State Colors
  static const Color success = Color(0xFF10B981);
  static const Color error = Color(0xFFEF4444);
  static const Color warning = Color(0xFFF59E0B);
  static const Color info = Color(0xFF3B82F6);

  // Gradients
  static const LinearGradient primaryGradient = LinearGradient(
    colors: [Color(0xFFFFB300), Color(0xFFFF8F00)],
    begin: Alignment.topLeft,
    end: Alignment.bottomRight,
  );

  static const LinearGradient darkCardGradient = LinearGradient(
    colors: [Color(0xFF232A34), Color(0xFF191F28)],
    begin: Alignment.topLeft,
    end: Alignment.bottomRight,
  );

  static const LinearGradient headerGradient = LinearGradient(
    colors: [Color(0x33FFB300), Colors.transparent],
    begin: Alignment.topCenter,
    end: Alignment.bottomCenter,
  );

  static const LinearGradient neonAccentGradient = LinearGradient(
    colors: [Color(0xFF00E5FF), Color(0xFF0091EA)],
    begin: Alignment.centerLeft,
    end: Alignment.centerRight,
  );
}

import '../models/driver_user_model.dart';
import '../../../../core/error/failures.dart';

abstract class AuthRemoteDataSource {
  Future<DriverUserModel> loginWithEmail({
    required String email,
    required String password,
  });

  Future<DriverUserModel> loginWithPhone({
    required String phone,
    required String password,
  });

  Future<void> sendOtp({required String phone});

  Future<DriverUserModel> verifyOtp({
    required String phone,
    required String otp,
  });
}

class AuthRemoteDataSourceImpl implements AuthRemoteDataSource {
  @override
  Future<DriverUserModel> loginWithEmail({
    required String email,
    required String password,
  }) async {
    // Simulate real-world network delay
    await Future.delayed(const Duration(milliseconds: 1200));

    if (password.length < 6) {
      throw const AuthFailure('Password must be at least 6 characters');
    }

    // Mock successful authentication for demonstration
    return DriverUserModel(
      id: 'drv_${DateTime.now().millisecondsSinceEpoch}',
      name: 'Alexander Hayes',
      email: email,
      phone: '+1 (555) 234-5678',
      vehicleType: 'Executive Sedan',
      vehicleNumber: 'NYC-7892',
      rating: 4.98,
      isVerified: true,
    );
  }

  @override
  Future<DriverUserModel> loginWithPhone({
    required String phone,
    required String password,
  }) async {
    // Simulate real-world network delay
    await Future.delayed(const Duration(milliseconds: 1200));

    if (password.length < 6) {
      throw const AuthFailure('Invalid credentials. Password too short.');
    }

    return DriverUserModel(
      id: 'drv_${DateTime.now().millisecondsSinceEpoch}',
      name: 'Alexander Hayes',
      email: 'alexander.driver@cardriver.io',
      phone: phone,
      vehicleType: 'Luxury SUV',
      vehicleNumber: 'NYC-4521',
      rating: 4.96,
      isVerified: true,
    );
  }

  @override
  Future<void> sendOtp({required String phone}) async {
    await Future.delayed(const Duration(milliseconds: 800));
  }

  @override
  Future<DriverUserModel> verifyOtp({
    required String phone,
    required String otp,
  }) async {
    await Future.delayed(const Duration(milliseconds: 1000));
    if (otp != '1234' && otp != '123456') {
      throw const AuthFailure('Invalid OTP entered. Try 1234');
    }
    return DriverUserModel(
      id: 'drv_${DateTime.now().millisecondsSinceEpoch}',
      name: 'Alexander Hayes',
      email: 'alexander.driver@cardriver.io',
      phone: phone,
      vehicleType: 'Luxury Sedan',
      vehicleNumber: 'NYC-4521',
      rating: 4.96,
      isVerified: true,
    );
  }
}

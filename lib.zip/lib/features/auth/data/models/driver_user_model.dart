import '../../domain/entities/driver_user.dart';

class DriverUserModel extends DriverUser {
  const DriverUserModel({
    required super.id,
    required super.name,
    required super.email,
    required super.phone,
    super.avatarUrl,
    required super.vehicleType,
    required super.vehicleNumber,
    super.rating = 5.0,
    super.isVerified = true,
  });

  factory DriverUserModel.fromJson(Map<String, dynamic> json) {
    return DriverUserModel(
      id: json['id'] as String? ?? 'drv_${DateTime.now().millisecondsSinceEpoch}',
      name: json['name'] as String? ?? 'Driver Partner',
      email: json['email'] as String? ?? '',
      phone: json['phone'] as String? ?? '',
      avatarUrl: json['avatar_url'] as String?,
      vehicleType: json['vehicle_type'] as String? ?? 'Sedan Premier',
      vehicleNumber: json['vehicle_number'] as String? ?? 'DL 01 AB 1234',
      rating: (json['rating'] as num?)?.toDouble() ?? 4.95,
      isVerified: json['is_verified'] as bool? ?? true,
    );
  }

  Map<String, dynamic> toJson() {
    return {
      'id': id,
      'name': name,
      'email': email,
      'phone': phone,
      'avatar_url': avatarUrl,
      'vehicle_type': vehicleType,
      'vehicle_number': vehicleNumber,
      'rating': rating,
      'is_verified': isVerified,
    };
  }
}

import '../entities/driver_user.dart';

/// Authentication repository contract in Domain layer.
abstract class AuthRepository {
  Future<DriverUser> loginWithEmail({
    required String email,
    required String password,
  });

  Future<DriverUser> loginWithPhone({
    required String phone,
    required String password,
  });

  Future<void> sendOtp({required String phone});

  Future<DriverUser> verifyOtp({
    required String phone,
    required String otp,
  });
}

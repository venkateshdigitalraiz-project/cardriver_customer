import '../entities/driver_user.dart';
import '../repositories/auth_repository.dart';

/// Use case for logging in via Email or Phone credentials.
class LoginWithEmailUseCase {
  final AuthRepository repository;

  LoginWithEmailUseCase(this.repository);

  Future<DriverUser> call({
    required String email,
    required String password,
  }) async {
    return await repository.loginWithEmail(
      email: email,
      password: password,
    );
  }
}

class LoginWithPhoneUseCase {
  final AuthRepository repository;

  LoginWithPhoneUseCase(this.repository);

  Future<DriverUser> call({
    required String phone,
    required String password,
  }) async {
    return await repository.loginWithPhone(
      phone: phone,
      password: password,
    );
  }
}

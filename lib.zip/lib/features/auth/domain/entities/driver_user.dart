import 'package:equatable/equatable.dart';

/// Domain Entity representing an authenticated Driver / Customer User.
class DriverUser extends Equatable {
  final String id;
  final String name;
  final String email;
  final String phone;
  final String? avatarUrl;
  final String vehicleType;
  final String vehicleNumber;
  final double rating;
  final bool isVerified;

  const DriverUser({
    required this.id,
    required this.name,
    required this.email,
    required this.phone,
    this.avatarUrl,
    required this.vehicleType,
    required this.vehicleNumber,
    this.rating = 5.0,
    this.isVerified = true,
  });

  @override
  List<Object?> get props => [
        id,
        name,
        email,
        phone,
        avatarUrl,
        vehicleType,
        vehicleNumber,
        rating,
        isVerified,
      ];
}

import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import '../../../../core/theme/app_colors.dart';
import '../../../../core/theme/app_dimens.dart';
import '../../../../core/theme/app_typography.dart';
import '../../../../core/utils/validators.dart';
import '../../../../core/widgets/custom_button.dart';
import '../../../../core/widgets/custom_text_field.dart';
import '../bloc/login_bloc.dart';
import '../bloc/login_event.dart';
import '../bloc/login_state.dart';

class LoginForm extends StatefulWidget {
  const LoginForm({super.key});

  @override
  State<LoginForm> createState() => _LoginFormState();
}

class _LoginFormState extends State<LoginForm> {
  final _formKey = GlobalKey<FormState>();
  final _phoneController = TextEditingController();
  final _emailController = TextEditingController();
  final _passwordController = TextEditingController();

  static const List<Map<String, String>> _countryCodes = [
    {'code': '+1', 'flag': '🇺🇸', 'country': 'United States'},
    {'code': '+44', 'flag': '🇬🇧', 'country': 'United Kingdom'},
    {'code': '+91', 'flag': '🇮🇳', 'country': 'India'},
    {'code': '+971', 'flag': '🇦🇪', 'country': 'UAE'},
    {'code': '+65', 'flag': '🇸🇬', 'country': 'Singapore'},
    {'code': '+49', 'flag': '🇩🇪', 'country': 'Germany'},
    {'code': '+33', 'flag': '🇫🇷', 'country': 'France'},
    {'code': '+61', 'flag': '🇦🇺', 'country': 'Australia'},
    {'code': '+81', 'flag': '🇯🇵', 'country': 'Japan'},
  ];

  @override
  void dispose() {
    _phoneController.dispose();
    _emailController.dispose();
    _passwordController.dispose();
    super.dispose();
  }

  void _fillDemoAccount(LoginMode mode) {
    if (mode == LoginMode.phone) {
      _phoneController.text = '9876543210';
      _passwordController.text = 'driver123';
    } else {
      _emailController.text = 'alexander.driver@cardriver.io';
      _passwordController.text = 'driver123';
    }
  }

  void _showCountryPicker(BuildContext context) {
    final isDark = Theme.of(context).brightness == Brightness.dark;

    showModalBottomSheet(
      context: context,
      backgroundColor: isDark ? AppColors.cardDark : AppColors.cardLight,
      shape: const RoundedRectangleBorder(
        borderRadius: BorderRadius.vertical(top: Radius.circular(AppDimens.radiusLarge)),
      ),
      builder: (bottomSheetContext) {
        return SafeArea(
          child: Column(
            mainAxisSize: MainAxisSize.min,
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Padding(
                padding: const EdgeInsets.all(AppDimens.p20),
                child: Text(
                  'Select Country Code',
                  style: AppTypography.titleMedium.copyWith(
                    color: isDark ? AppColors.textPrimaryDark : AppColors.textPrimaryLight,
                  ),
                ),
              ),
              const Divider(height: 1),
              Expanded(
                child: ListView.separated(
                  itemCount: _countryCodes.length,
                  separatorBuilder: (_, index) => const Divider(height: 1),
                  itemBuilder: (context, index) {
                    final item = _countryCodes[index];
                    return ListTile(
                      leading: Text(item['flag']!, style: const TextStyle(fontSize: 24)),
                      title: Text(
                        item['country']!,
                        style: AppTypography.bodyLarge.copyWith(
                          color: isDark ? AppColors.textPrimaryDark : AppColors.textPrimaryLight,
                        ),
                      ),
                      trailing: Text(
                        item['code']!,
                        style: AppTypography.labelLarge.copyWith(
                          color: isDark ? AppColors.primary : AppColors.primaryDark,
                        ),
                      ),
                      onTap: () {
                        context.read<LoginBloc>().add(
                              CountryCodeChanged(
                                dialCode: item['code']!,
                                flag: item['flag']!,
                              ),
                            );
                        Navigator.pop(bottomSheetContext);
                      },
                    );
                  },
                ),
              ),
            ],
          ),
        );
      },
    );
  }

  void _onSubmit(LoginState state) {
    if (_formKey.currentState?.validate() ?? false) {
      if (state.mode == LoginMode.phone) {
        context.read<LoginBloc>().add(
              PhoneLoginSubmitted(
                phone: _phoneController.text.trim(),
                password: _passwordController.text,
              ),
            );
      } else {
        context.read<LoginBloc>().add(
              EmailLoginSubmitted(
                email: _emailController.text.trim(),
                password: _passwordController.text,
              ),
            );
      }
    }
  }

  @override
  Widget build(BuildContext context) {
    final isDark = Theme.of(context).brightness == Brightness.dark;

    return BlocBuilder<LoginBloc, LoginState>(
      builder: (context, state) {
        final isLoading = state.status == LoginStatus.loading;

        return Form(
          key: _formKey,
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              // Phone Input Field
              if (state.mode == LoginMode.phone) ...[
                CustomTextField(
                  controller: _phoneController,
                  label: 'Phone Number',
                  hintText: 'Enter driver phone number',
                  keyboardType: TextInputType.phone,
                  textInputAction: TextInputAction.next,
                  validator: Validators.validatePhone,
                  prefixIcon: GestureDetector(
                    onTap: () => _showCountryPicker(context),
                    child: Container(
                      padding: const EdgeInsets.only(left: AppDimens.p12, right: AppDimens.p8),
                      child: Row(
                        mainAxisSize: MainAxisSize.min,
                        children: [
                          Text(state.flag, style: const TextStyle(fontSize: 18)),
                          const SizedBox(width: AppDimens.p4),
                          Text(
                            state.dialCode,
                            style: AppTypography.labelMedium.copyWith(
                              color: isDark ? AppColors.textPrimaryDark : AppColors.textPrimaryLight,
                            ),
                          ),
                          Icon(
                            Icons.arrow_drop_down,
                            size: 18,
                            color: isDark ? AppColors.textTertiaryDark : AppColors.textTertiaryLight,
                          ),
                          Container(
                            height: 20,
                            width: 1,
                            margin: const EdgeInsets.symmetric(horizontal: AppDimens.p8),
                            color: isDark ? AppColors.inputBorderDark : AppColors.inputBorderLight,
                          ),
                        ],
                      ),
                    ),
                  ),
                ),
              ] else ...[
                // Email Input Field
                CustomTextField(
                  controller: _emailController,
                  label: 'Email Address',
                  hintText: 'name@driverpartner.com',
                  keyboardType: TextInputType.emailAddress,
                  textInputAction: TextInputAction.next,
                  validator: Validators.validateEmail,
                  prefixIcon: const Icon(Icons.mail_outline_rounded),
                ),
              ],

              const SizedBox(height: AppDimens.p16),

              // Password Input Field
              CustomTextField(
                controller: _passwordController,
                label: 'Driver Password',
                hintText: 'Enter your account password',
                obscureText: state.obscurePassword,
                textInputAction: TextInputAction.done,
                validator: Validators.validatePassword,
                prefixIcon: const Icon(Icons.lock_outline_rounded),
                suffixIcon: IconButton(
                  icon: Icon(
                    state.obscurePassword
                        ? Icons.visibility_off_outlined
                        : Icons.visibility_outlined,
                  ),
                  onPressed: () {
                    context.read<LoginBloc>().add(const TogglePasswordVisibility());
                  },
                ),
                onSubmitted: (_) => _onSubmit(state),
              ),

              const SizedBox(height: AppDimens.p12),

              // Remember Me & Forgot Password
              Row(
                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                children: [
                  // Remember Me checkbox
                  InkWell(
                    onTap: () {
                      context.read<LoginBloc>().add(const ToggleRememberMe());
                    },
                    borderRadius: BorderRadius.circular(AppDimens.radiusSmall),
                    child: Padding(
                      padding: const EdgeInsets.symmetric(vertical: AppDimens.p4),
                      child: Row(
                        children: [
                          SizedBox(
                            height: 20,
                            width: 20,
                            child: Checkbox(
                              value: state.rememberMe,
                              onChanged: (_) {
                                context.read<LoginBloc>().add(const ToggleRememberMe());
                              },
                              activeColor: AppColors.primary,
                              checkColor: Colors.black,
                              shape: RoundedRectangleBorder(
                                borderRadius: BorderRadius.circular(4),
                              ),
                            ),
                          ),
                          const SizedBox(width: AppDimens.p8),
                          Text(
                            'Remember Me',
                            style: AppTypography.bodySmall.copyWith(
                              color: isDark
                                  ? AppColors.textSecondaryDark
                                  : AppColors.textSecondaryLight,
                            ),
                          ),
                        ],
                      ),
                    ),
                  ),

                  // Forgot Password Button
                  TextButton(
                    onPressed: () {
                      ScaffoldMessenger.of(context).showSnackBar(
                        SnackBar(
                          content: const Text(
                            'Password reset instructions sent to your registered contact.',
                          ),
                          backgroundColor: isDark ? AppColors.surfaceDark : AppColors.cardDark,
                        ),
                      );
                    },
                    style: TextButton.styleFrom(
                      padding: EdgeInsets.zero,
                      minimumSize: Size.zero,
                      tapTargetSize: MaterialTapTargetSize.shrinkWrap,
                    ),
                    child: Text(
                      'Forgot Password?',
                      style: AppTypography.labelSmall.copyWith(
                        color: isDark ? AppColors.primary : AppColors.primaryDark,
                        fontWeight: FontWeight.w700,
                      ),
                    ),
                  ),
                ],
              ),

              const SizedBox(height: AppDimens.p16),

              // Quick Fill Demo Chip for testability
              Align(
                alignment: Alignment.centerLeft,
                child: ActionChip(
                  avatar: const Icon(Icons.flash_on_rounded, size: 16, color: Colors.amber),
                  label: Text(
                    'Auto-fill Demo Credentials',
                    style: AppTypography.labelSmall.copyWith(
                      color: isDark ? AppColors.textSecondaryDark : AppColors.textSecondaryLight,
                    ),
                  ),
                  backgroundColor: isDark ? AppColors.surfaceDark : AppColors.inputFillLight,
                  side: BorderSide(
                    color: isDark ? AppColors.cardBorderDark : AppColors.cardBorderLight,
                  ),
                  onPressed: () => _fillDemoAccount(state.mode),
                ),
              ),

              const SizedBox(height: AppDimens.p24),

              // Primary Action Submit Button
              CustomButton(
                text: 'Sign In as Driver',
                isLoading: isLoading,
                onPressed: () => _onSubmit(state),
              ),
            ],
          ),
        );
      },
    );
  }
}

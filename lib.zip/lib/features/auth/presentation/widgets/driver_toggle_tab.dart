import 'package:flutter/material.dart';
import '../../../../core/theme/app_colors.dart';
import '../../../../core/theme/app_dimens.dart';
import '../../../../core/theme/app_typography.dart';
import '../bloc/login_event.dart';

class DriverToggleTab extends StatelessWidget {
  final LoginMode currentMode;
  final ValueChanged<LoginMode> onModeChanged;

  const DriverToggleTab({
    super.key,
    required this.currentMode,
    required this.onModeChanged,
  });

  @override
  Widget build(BuildContext context) {
    final isDark = Theme.of(context).brightness == Brightness.dark;

    return Container(
      padding: const EdgeInsets.all(AppDimens.p4),
      decoration: BoxDecoration(
        color: isDark ? AppColors.surfaceDark : AppColors.inputFillLight,
        borderRadius: AppDimens.borderRadiusMedium,
        border: Border.all(
          color: isDark ? AppColors.cardBorderDark : AppColors.cardBorderLight,
        ),
      ),
      child: Row(
        children: [
          _buildTab(
            context: context,
            title: 'Phone Number',
            icon: Icons.phone_android_rounded,
            mode: LoginMode.phone,
            isActive: currentMode == LoginMode.phone,
            isDark: isDark,
          ),
          _buildTab(
            context: context,
            title: 'Email Address',
            icon: Icons.mail_outline_rounded,
            mode: LoginMode.email,
            isActive: currentMode == LoginMode.email,
            isDark: isDark,
          ),
        ],
      ),
    );
  }

  Widget _buildTab({
    required BuildContext context,
    required String title,
    required IconData icon,
    required LoginMode mode,
    required bool isActive,
    required bool isDark,
  }) {
    return Expanded(
      child: GestureDetector(
        onTap: () => onModeChanged(mode),
        child: AnimatedContainer(
          duration: const Duration(milliseconds: 200),
          padding: const EdgeInsets.symmetric(vertical: AppDimens.p12),
          decoration: BoxDecoration(
            color: isActive
                ? (isDark ? AppColors.cardDark : Colors.white)
                : Colors.transparent,
            borderRadius: BorderRadius.circular(AppDimens.radiusSmall + 2),
            boxShadow: isActive
                ? [
                    BoxShadow(
                      color: Colors.black.withValues(alpha: 0.08),
                      blurRadius: 8,
                      offset: const Offset(0, 2),
                    ),
                  ]
                : [],
          ),
          child: Row(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              Icon(
                icon,
                size: 18,
                color: isActive
                    ? (isDark ? AppColors.primary : AppColors.primaryDark)
                    : (isDark ? AppColors.textTertiaryDark : AppColors.textTertiaryLight),
              ),
              const SizedBox(width: AppDimens.p8),
              Text(
                title,
                style: AppTypography.labelMedium.copyWith(
                  color: isActive
                      ? (isDark ? AppColors.textPrimaryDark : AppColors.textPrimaryLight)
                      : (isDark ? AppColors.textTertiaryDark : AppColors.textTertiaryLight),
                  fontWeight: isActive ? FontWeight.w700 : FontWeight.w500,
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}

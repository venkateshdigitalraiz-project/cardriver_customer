import 'package:flutter/material.dart';
import '../../../../core/theme/app_colors.dart';
import '../../../../core/theme/app_dimens.dart';
import '../../../../core/theme/app_typography.dart';
import '../../../../core/widgets/social_auth_button.dart';

class LoginFooter extends StatelessWidget {
  const LoginFooter({super.key});

  @override
  Widget build(BuildContext context) {
    final isDark = Theme.of(context).brightness == Brightness.dark;

    return Column(
      children: [
        // Or divider
        Row(
          children: [
            Expanded(
              child: Divider(
                color: isDark ? AppColors.dividerDark : AppColors.dividerLight,
              ),
            ),
            Padding(
              padding: const EdgeInsets.symmetric(horizontal: AppDimens.p16),
              child: Text(
                'or continue with',
                style: AppTypography.labelSmall.copyWith(
                  color: isDark ? AppColors.textTertiaryDark : AppColors.textTertiaryLight,
                ),
              ),
            ),
            Expanded(
              child: Divider(
                color: isDark ? AppColors.dividerDark : AppColors.dividerLight,
              ),
            ),
          ],
        ),

        const SizedBox(height: AppDimens.p20),

        // Social Sign-in Buttons
        Row(
          children: [
            SocialAuthButton(
              provider: SocialProvider.google,
              onPressed: () {
                ScaffoldMessenger.of(context).showSnackBar(
                  const SnackBar(content: Text('Google Driver Authentication initiated')),
                );
              },
            ),
            const SizedBox(width: AppDimens.p12),
            SocialAuthButton(
              provider: SocialProvider.apple,
              onPressed: () {
                ScaffoldMessenger.of(context).showSnackBar(
                  const SnackBar(content: Text('Apple Driver Authentication initiated')),
                );
              },
            ),
          ],
        ),

        const SizedBox(height: AppDimens.p32),

        // Registration Link
        Row(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Text(
              'Not registered yet? ',
              style: AppTypography.bodyMedium.copyWith(
                color: isDark ? AppColors.textSecondaryDark : AppColors.textSecondaryLight,
              ),
            ),
            GestureDetector(
              onTap: () {
                ScaffoldMessenger.of(context).showSnackBar(
                  const SnackBar(content: Text('Redirecting to Driver Partner Onboarding...')),
                );
              },
              child: Text(
                'Become a Partner',
                style: AppTypography.labelMedium.copyWith(
                  color: isDark ? AppColors.primary : AppColors.primaryDark,
                  fontWeight: FontWeight.w700,
                  decoration: TextDecoration.underline,
                ),
              ),
            ),
          ],
        ),

        const SizedBox(height: AppDimens.p16),

        // Driver Support / Hotline
        Row(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Icon(
              Icons.headset_mic_rounded,
              size: 16,
              color: isDark ? AppColors.textTertiaryDark : AppColors.textTertiaryLight,
            ),
            const SizedBox(width: AppDimens.p6),
            Text(
              '24/7 Driver Partner Support: 1-800-CAR-DRIV',
              style: AppTypography.bodySmall.copyWith(
                color: isDark ? AppColors.textTertiaryDark : AppColors.textTertiaryLight,
              ),
            ),
          ],
        ),
      ],
    );
  }
}

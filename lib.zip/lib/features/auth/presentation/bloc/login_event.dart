import 'package:equatable/equatable.dart';

enum LoginMode { phone, email }

abstract class LoginEvent extends Equatable {
  const LoginEvent();

  @override
  List<Object?> get props => [];
}

class LoginModeChanged extends LoginEvent {
  final LoginMode mode;
  const LoginModeChanged(this.mode);

  @override
  List<Object?> get props => [mode];
}

class TogglePasswordVisibility extends LoginEvent {
  const TogglePasswordVisibility();
}

class ToggleRememberMe extends LoginEvent {
  const ToggleRememberMe();
}

class CountryCodeChanged extends LoginEvent {
  final String dialCode;
  final String flag;

  const CountryCodeChanged({required this.dialCode, required this.flag});

  @override
  List<Object?> get props => [dialCode, flag];
}

class EmailLoginSubmitted extends LoginEvent {
  final String email;
  final String password;

  const EmailLoginSubmitted({required this.email, required this.password});

  @override
  List<Object?> get props => [email, password];
}

class PhoneLoginSubmitted extends LoginEvent {
  final String phone;
  final String password;

  const PhoneLoginSubmitted({required this.phone, required this.password});

  @override
  List<Object?> get props => [phone, password];
}

class ResetLoginState extends LoginEvent {
  const ResetLoginState();
}

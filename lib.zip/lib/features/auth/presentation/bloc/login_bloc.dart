import 'package:flutter_bloc/flutter_bloc.dart';
import '../../../../core/error/failures.dart';
import '../../domain/usecases/login_usecase.dart';
import 'login_event.dart';
import 'login_state.dart';

class LoginBloc extends Bloc<LoginEvent, LoginState> {
  final LoginWithEmailUseCase loginWithEmailUseCase;
  final LoginWithPhoneUseCase loginWithPhoneUseCase;

  LoginBloc({
    required this.loginWithEmailUseCase,
    required this.loginWithPhoneUseCase,
  }) : super(const LoginState()) {
    on<LoginModeChanged>(_onLoginModeChanged);
    on<TogglePasswordVisibility>(_onTogglePasswordVisibility);
    on<ToggleRememberMe>(_onToggleRememberMe);
    on<CountryCodeChanged>(_onCountryCodeChanged);
    on<EmailLoginSubmitted>(_onEmailLoginSubmitted);
    on<PhoneLoginSubmitted>(_onPhoneLoginSubmitted);
    on<ResetLoginState>(_onResetLoginState);
  }

  void _onLoginModeChanged(LoginModeChanged event, Emitter<LoginState> emit) {
    emit(state.copyWith(
      mode: event.mode,
      status: LoginStatus.initial,
      clearError: true,
    ));
  }

  void _onTogglePasswordVisibility(TogglePasswordVisibility event, Emitter<LoginState> emit) {
    emit(state.copyWith(obscurePassword: !state.obscurePassword));
  }

  void _onToggleRememberMe(ToggleRememberMe event, Emitter<LoginState> emit) {
    emit(state.copyWith(rememberMe: !state.rememberMe));
  }

  void _onCountryCodeChanged(CountryCodeChanged event, Emitter<LoginState> emit) {
    emit(state.copyWith(dialCode: event.dialCode, flag: event.flag));
  }

  void _onResetLoginState(ResetLoginState event, Emitter<LoginState> emit) {
    emit(state.copyWith(status: LoginStatus.initial, clearError: true));
  }

  Future<void> _onEmailLoginSubmitted(EmailLoginSubmitted event, Emitter<LoginState> emit) async {
    emit(state.copyWith(status: LoginStatus.loading, clearError: true));

    try {
      final user = await loginWithEmailUseCase(
        email: event.email,
        password: event.password,
      );
      emit(state.copyWith(
        status: LoginStatus.success,
        user: user,
      ));
    } on Failure catch (failure) {
      emit(state.copyWith(
        status: LoginStatus.failure,
        errorMessage: failure.message,
      ));
    } catch (e) {
      emit(state.copyWith(
        status: LoginStatus.failure,
        errorMessage: 'An unexpected error occurred. Please try again.',
      ));
    }
  }

  Future<void> _onPhoneLoginSubmitted(PhoneLoginSubmitted event, Emitter<LoginState> emit) async {
    emit(state.copyWith(status: LoginStatus.loading, clearError: true));

    try {
      final formattedPhone = '${state.dialCode} ${event.phone.trim()}';
      final user = await loginWithPhoneUseCase(
        phone: formattedPhone,
        password: event.password,
      );
      emit(state.copyWith(
        status: LoginStatus.success,
        user: user,
      ));
    } on Failure catch (failure) {
      emit(state.copyWith(
        status: LoginStatus.failure,
        errorMessage: failure.message,
      ));
    } catch (e) {
      emit(state.copyWith(
        status: LoginStatus.failure,
        errorMessage: 'An unexpected error occurred. Please try again.',
      ));
    }
  }
}

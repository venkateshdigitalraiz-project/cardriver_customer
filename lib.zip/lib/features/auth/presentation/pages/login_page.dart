import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import '../../../../core/theme/app_colors.dart';
import '../../../../core/theme/app_dimens.dart';
import '../../../../core/theme/app_typography.dart';
import '../bloc/login_bloc.dart';
import '../bloc/login_event.dart';
import '../bloc/login_state.dart';
import '../widgets/driver_toggle_tab.dart';
import '../widgets/login_footer.dart';
import '../widgets/login_form.dart';
import '../widgets/login_header.dart';

class LoginPage extends StatelessWidget {
  final VoidCallback? onToggleTheme;
  final bool isDarkMode;

  const LoginPage({
    super.key,
    this.onToggleTheme,
    this.isDarkMode = true,
  });

  void _showSuccessDialog(BuildContext context, LoginState state) {
    final isDark = Theme.of(context).brightness == Brightness.dark;
    final user = state.user;

    showDialog(
      context: context,
      barrierDismissible: false,
      builder: (dialogContext) {
        return AlertDialog(
          backgroundColor: isDark ? AppColors.cardDark : AppColors.cardLight,
          shape: const RoundedRectangleBorder(
            borderRadius: AppDimens.borderRadiusLarge,
          ),
          content: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              Container(
                height: 72,
                width: 72,
                decoration: const BoxDecoration(
                  color: AppColors.success,
                  shape: BoxShape.circle,
                ),
                child: const Icon(
                  Icons.check_rounded,
                  color: Colors.white,
                  size: 44,
                ),
              ),
              const SizedBox(height: AppDimens.p16),
              Text(
                'Welcome, ${user?.name ?? 'Captain'}!',
                style: AppTypography.titleLarge.copyWith(
                  color: isDark ? AppColors.textPrimaryDark : AppColors.textPrimaryLight,
                ),
                textAlign: TextAlign.center,
              ),
              const SizedBox(height: AppDimens.p8),
              Text(
                'Authenticated successfully as an active Driver Partner.',
                style: AppTypography.bodyMedium.copyWith(
                  color: isDark ? AppColors.textSecondaryDark : AppColors.textSecondaryLight,
                ),
                textAlign: TextAlign.center,
              ),
              const SizedBox(height: AppDimens.p16),
              Container(
                padding: const EdgeInsets.all(AppDimens.p12),
                decoration: BoxDecoration(
                  color: isDark ? AppColors.surfaceDark : AppColors.inputFillLight,
                  borderRadius: AppDimens.borderRadiusMedium,
                  border: Border.all(
                    color: isDark ? AppColors.cardBorderDark : AppColors.cardBorderLight,
                  ),
                ),
                child: Row(
                  children: [
                    const Icon(Icons.directions_car_rounded, color: AppColors.primary, size: 24),
                    const SizedBox(width: AppDimens.p12),
                    Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Text(
                          user?.vehicleType ?? 'Executive Sedan',
                          style: AppTypography.labelMedium.copyWith(
                            color: isDark ? AppColors.textPrimaryDark : AppColors.textPrimaryLight,
                          ),
                        ),
                        Text(
                          user?.vehicleNumber ?? 'DL 01 AB 1234',
                          style: AppTypography.bodySmall.copyWith(
                            color: isDark ? AppColors.textTertiaryDark : AppColors.textTertiaryLight,
                          ),
                        ),
                      ],
                    ),
                    const Spacer(),
                    Container(
                      padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 4),
                      decoration: BoxDecoration(
                        color: AppColors.primary.withValues(alpha: 0.2),
                        borderRadius: BorderRadius.circular(6),
                      ),
                      child: Row(
                        children: [
                          const Icon(Icons.star_rounded, size: 14, color: AppColors.primary),
                          const SizedBox(width: 2),
                          Text(
                            user?.rating.toStringAsFixed(1) ?? '5.0',
                            style: AppTypography.labelSmall.copyWith(
                              color: isDark ? AppColors.primaryLight : AppColors.primaryDark,
                              fontWeight: FontWeight.bold,
                            ),
                          ),
                        ],
                      ),
                    ),
                  ],
                ),
              ),
            ],
          ),
          actions: [
            SizedBox(
              width: double.infinity,
              child: ElevatedButton(
                onPressed: () {
                  Navigator.pop(dialogContext);
                  context.read<LoginBloc>().add(const ResetLoginState());
                },
                child: const Text('Go to Driver Dashboard'),
              ),
            ),
          ],
        );
      },
    );
  }

  @override
  Widget build(BuildContext context) {
    final isDark = Theme.of(context).brightness == Brightness.dark;

    return BlocListener<LoginBloc, LoginState>(
      listener: (context, state) {
        if (state.status == LoginStatus.failure && state.errorMessage != null) {
          ScaffoldMessenger.of(context).showSnackBar(
            SnackBar(
              backgroundColor: AppColors.error,
              behavior: SnackBarBehavior.floating,
              shape: const RoundedRectangleBorder(
                borderRadius: AppDimens.borderRadiusSmall,
              ),
              content: Row(
                children: [
                  const Icon(Icons.error_outline_rounded, color: Colors.white),
                  const SizedBox(width: AppDimens.p12),
                  Expanded(
                    child: Text(
                      state.errorMessage!,
                      style: AppTypography.bodyMedium.copyWith(color: Colors.white),
                    ),
                  ),
                ],
              ),
            ),
          );
        } else if (state.status == LoginStatus.success) {
          _showSuccessDialog(context, state);
        }
      },
      child: Scaffold(
        appBar: AppBar(
          backgroundColor: Colors.transparent,
          elevation: 0,
          scrolledUnderElevation: 0,
          actions: [
            if (onToggleTheme != null)
              IconButton(
                tooltip: isDarkMode ? 'Switch to Light Theme' : 'Switch to Dark Theme',
                icon: Icon(
                  isDarkMode ? Icons.light_mode_rounded : Icons.dark_mode_rounded,
                  color: isDark ? AppColors.primary : AppColors.primaryDark,
                ),
                onPressed: onToggleTheme,
              ),
            const SizedBox(width: AppDimens.p8),
          ],
        ),
        body: SafeArea(
          child: LayoutBuilder(
            builder: (context, constraints) {
              return SingleChildScrollView(
                physics: const BouncingScrollPhysics(),
                padding: const EdgeInsets.symmetric(horizontal: AppDimens.p24),
                child: ConstrainedBox(
                  constraints: BoxConstraints(minHeight: constraints.maxHeight),
                  child: IntrinsicHeight(
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        const LoginHeader(),
                        const SizedBox(height: AppDimens.p24),

                        // Login Mode Tab Switcher (Phone / Email)
                        BlocBuilder<LoginBloc, LoginState>(
                          buildWhen: (previous, current) => previous.mode != current.mode,
                          builder: (context, state) {
                            return DriverToggleTab(
                              currentMode: state.mode,
                              onModeChanged: (mode) {
                                context.read<LoginBloc>().add(LoginModeChanged(mode));
                              },
                            );
                          },
                        ),

                        const SizedBox(height: AppDimens.p24),

                        // Login Form (Fields + Button)
                        const LoginForm(),

                        const SizedBox(height: AppDimens.p32),

                        // Login Footer (Social sign-in + Driver partner CTA)
                        const LoginFooter(),

                        const SizedBox(height: AppDimens.p24),
                      ],
                    ),
                  ),
                ),
              );
            },
          ),
        ),
      ),
    );
  }
}
